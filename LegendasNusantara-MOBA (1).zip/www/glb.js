/* Pemuat & renderer GLB mini (WebGL2) dengan skinning + animasi. Tanpa dependensi. */
(()=>{
'use strict';
const M={
 id:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
 mul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s}return o},
 trs(t,q,s){const[x,y,z,w]=q,x2=x+x,y2=y+y,z2=z+z,xx=x*x2,xy=x*y2,xz=x*z2,yy=y*y2,yz=y*z2,zz=z*z2,wx=w*x2,wy=w*y2,wz=w*z2;
  return new Float32Array([(1-(yy+zz))*s[0],(xy+wz)*s[0],(xz-wy)*s[0],0,(xy-wz)*s[1],(1-(xx+zz))*s[1],(yz+wx)*s[1],0,(xz+wy)*s[2],(yz-wx)*s[2],(1-(xx+yy))*s[2],0,t[0],t[1],t[2],1])},
 inv(m){const o=new Float32Array(16),a=m;
  const a00=a[0],a01=a[1],a02=a[2],a03=a[3],a10=a[4],a11=a[5],a12=a[6],a13=a[7],a20=a[8],a21=a[9],a22=a[10],a23=a[11],a30=a[12],a31=a[13],a32=a[14],a33=a[15];
  const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
  let d=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;if(!d)return M.id();d=1/d;
  o[0]=(a11*b11-a12*b10+a13*b09)*d;o[1]=(a02*b10-a01*b11-a03*b09)*d;o[2]=(a31*b05-a32*b04+a33*b03)*d;o[3]=(a22*b04-a21*b05-a23*b03)*d;
  o[4]=(a12*b08-a10*b11-a13*b07)*d;o[5]=(a00*b11-a02*b08+a03*b07)*d;o[6]=(a32*b02-a30*b05-a33*b01)*d;o[7]=(a20*b05-a22*b02+a23*b01)*d;
  o[8]=(a10*b10-a11*b08+a13*b06)*d;o[9]=(a01*b08-a00*b10-a03*b06)*d;o[10]=(a30*b04-a31*b02+a33*b00)*d;o[11]=(a21*b02-a20*b04-a23*b00)*d;
  o[12]=(a11*b07-a10*b09-a12*b06)*d;o[13]=(a00*b09-a01*b07+a02*b06)*d;o[14]=(a31*b01-a30*b03-a32*b00)*d;o[15]=(a20*b03-a21*b01+a22*b00)*d;return o},
 rotX(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1])},
 rotY(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1])},
 move(x,y,z){const m=M.id();m[12]=x;m[13]=y;m[14]=z;return m},
 ortho(l,r,b,t,n,f){return new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1])}
};
const VS=`#version 300 es
layout(location=0) in vec3 aPos;layout(location=1) in vec3 aNrm;layout(location=2) in vec2 aUv;layout(location=3) in uvec4 aJ;layout(location=4) in vec4 aW;
uniform mat4 uJ[32];uniform mat4 uView;uniform mat4 uProj;
out vec3 vN;out vec2 vUv;out vec3 vP;
void main(){
 mat4 sk=aW.x*uJ[aJ.x]+aW.y*uJ[aJ.y]+aW.z*uJ[aJ.z]+aW.w*uJ[aJ.w];
 vec4 vp=uView*(sk*vec4(aPos,1.));
 vP=vp.xyz;vN=mat3(uView)*(mat3(sk)*aNrm);vUv=aUv;gl_Position=uProj*vp;}`;
const FS=`#version 300 es
precision highp float;
in vec3 vN;in vec2 vUv;in vec3 vP;
uniform sampler2D tBase;uniform sampler2D tNorm;uniform sampler2D tMR;uniform vec3 uRim;uniform float uFlash;
out vec4 o;
void main(){
 vec3 albedo=texture(tBase,vUv).rgb;
 vec3 N=normalize(vN);if(!gl_FrontFacing)N=-N;
 vec3 dp1=dFdx(vP),dp2=dFdy(vP);vec2 du1=dFdx(vUv),du2=dFdy(vUv);
 vec3 p2=cross(dp2,N),p1=cross(N,dp1);
 vec3 T=p2*du1.x+p1*du2.x;vec3 B=p2*du1.y+p1*du2.y;
 float iv=inversesqrt(max(max(dot(T,T),dot(B,B)),1e-12));
 vec3 nm=texture(tNorm,vUv).xyz*2.-1.;nm.xy*=.8;
 N=normalize(mat3(T*iv,B*iv,N)*nm);
 vec3 mr=texture(tMR,vUv).rgb;float rough=mr.g,metal=mr.b;
 vec3 L=normalize(vec3(-.45,.75,.8)),V=vec3(0.,0.,1.),H=normalize(L+V);
 float nl=max(dot(N,L),0.);float wrap=nl*.8+.2;
 float hemi=N.y*.5+.5;
 vec3 amb=mix(vec3(.28,.26,.30),vec3(.62,.66,.78),hemi);
 vec3 diff=albedo*(1.-metal*.55);
 vec3 col=diff*(amb*.85+vec3(1.,.94,.84)*wrap*.75);
 float sp=pow(max(dot(N,H),0.),mix(90.,14.,rough))*(1.-rough*.65);
 col+=sp*mix(vec3(.32),albedo*1.3,metal)*nl;
 vec3 env=mix(vec3(.18,.2,.26),vec3(.75,.85,1.),clamp(N.y*.5+.5,0.,1.));
 col+=env*albedo*metal*.35;
 float rim=pow(1.-max(dot(N,V),0.),3.);col+=uRim*rim*.55;
 col=mix(col,vec3(1.),uFlash);
 o=vec4(col,1.);}`;

class GLBModel{
 constructor(w,h){this.w=w||320;this.h=h||400;this.cv=document.createElement('canvas');this.cv.width=this.w;this.cv.height=this.h;
  const gl=this.gl=this.cv.getContext('webgl2',{alpha:true,premultipliedAlpha:true,antialias:true});this.ok=false;this.ready=false;
  if(!gl)return;
  const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o};
  const pr=this.pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);
  if(!gl.getProgramParameter(pr,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(pr));
  this.u={};['uJ','uView','uProj','uRim','uFlash','tBase','tNorm','tMR'].forEach(n=>this.u[n]=gl.getUniformLocation(pr,n));
  this.ok=true}
 async load(url){
  if(!this.ok)return false;const gl=this.gl;
  const buf=await (await fetch(url)).arrayBuffer();const dv=new DataView(buf);
  const jl=dv.getUint32(12,true),J=JSON.parse(new TextDecoder().decode(new Uint8Array(buf,20,jl))),bo=20+jl+8;this.json=J;
  const bvOf=i=>{const v=J.bufferViews[i];return{off:bo+(v.byteOffset||0),len:v.byteLength,stride:v.byteStride||0}};
  const acc=i=>J.accessors[i];
  const floats=i=>{const a=acc(i),v=bvOf(a.bufferView),n={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16}[a.type];return new Float32Array(buf.slice(v.off+(a.byteOffset||0),v.off+(a.byteOffset||0)+a.count*n*4))};
  // geometri
  const prim=J.meshes[0].primitives[0],A=prim.attributes;
  this.vao=gl.createVertexArray();gl.bindVertexArray(this.vao);
  const bufs={};const mkbuf=(bi,target)=>{const k=bi+':'+target;if(!bufs[k]){const v=bvOf(bi),b=gl.createBuffer();gl.bindBuffer(target,b);gl.bufferData(target,new Uint8Array(buf,v.off,v.len),gl.STATIC_DRAW);bufs[k]=b}else gl.bindBuffer(target,bufs[k])};
  const attr=(loc,ai,int)=>{const a=acc(ai),v=bvOf(a.bufferView),n={SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[a.type];mkbuf(a.bufferView,gl.ARRAY_BUFFER);gl.enableVertexAttribArray(loc);
   if(int)gl.vertexAttribIPointer(loc,n,a.componentType,v.stride,a.byteOffset||0);else gl.vertexAttribPointer(loc,n,a.componentType,!!a.normalized,v.stride,a.byteOffset||0)};
  attr(0,A.POSITION);attr(1,A.NORMAL);attr(2,A.TEXCOORD_0);
  const jt=acc(A.JOINTS_0).componentType;attr(3,A.JOINTS_0,true);attr(4,A.WEIGHTS_0);
  const ia=acc(prim.indices);mkbuf(ia.bufferView,gl.ELEMENT_ARRAY_BUFFER);this.idxCount=ia.count;this.idxType=ia.componentType;this.idxOff=ia.byteOffset||0;
  gl.bindVertexArray(null);
  // tekstur
  const mat=J.materials[prim.material||0],pm=mat.pbrMetallicRoughness||{};
  const texOf=async(ti,def)=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
   if(ti===undefined){gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array(def));return t}
   const im=J.images[J.textures[ti].source],v=bvOf(im.bufferView);
   const bmp=await createImageBitmap(new Blob([new Uint8Array(buf,v.off,v.len)],{type:im.mimeType||'image/jpeg'}));
   gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,bmp);gl.generateMipmap(gl.TEXTURE_2D);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
   const ext=gl.getExtension('EXT_texture_filter_anisotropic');if(ext)gl.texParameterf(gl.TEXTURE_2D,ext.TEXTURE_MAX_ANISOTROPY_EXT,4);return t};
  this.tBase=await texOf(pm.baseColorTexture&&pm.baseColorTexture.index,[200,200,200,255]);
  this.tNorm=await texOf(mat.normalTexture&&mat.normalTexture.index,[128,128,255,255]);
  this.tMR=await texOf(pm.metallicRoughnessTexture&&pm.metallicRoughnessTexture.index,[255,160,0,255]);
  // rangka & animasi
  const nodes=this.nodes=J.nodes.map(n=>({t:n.translation||[0,0,0],r:n.rotation||[0,0,0,1],s:n.scale||[1,1,1],ch:n.children||[],p:-1,mesh:n.mesh,skin:n.skin,m:n.matrix}));
  nodes.forEach((n,i)=>n.ch.forEach(c=>nodes[c].p=i));
  this.meshNode=nodes.findIndex(n=>n.skin!==undefined);
  const sk=J.skins[0];this.joints=sk.joints;this.ibm=floats(sk.inverseBindMatrices);
  this.order=[];const walk=i=>{this.order.push(i);nodes[i].ch.forEach(walk)};J.scenes[0].nodes.forEach(walk);
  this.anims={};(J.animations||[]).forEach(a=>{let d=0;const ch=a.channels.map(c=>{const s=a.samplers[c.sampler],tm=floats(s.input);d=Math.max(d,tm[tm.length-1]);return{node:c.target.node,path:c.target.path,times:tm,vals:floats(s.output)}});this.anims[a.name]={dur:d,ch}});
  this.jm=new Float32Array(32*16);this.ready=true;return true}
 pose(name,time){
  const nodes=this.nodes,loc=nodes.map(n=>({t:n.t,r:n.r,s:n.s}));
  const an=this.anims[name];
  if(an){const T=an.dur>0?(time%an.dur+an.dur)%an.dur:0;
   for(const c of an.ch){const tm=c.times;let i=0;if(tm.length>1){let lo=0,hi=tm.length-1;while(hi-lo>1){const mid=(lo+hi)>>1;if(tm[mid]<=T)lo=mid;else hi=mid}i=lo}
    const j=Math.min(i+1,tm.length-1),f=j===i?0:(T-tm[i])/(tm[j]-tm[i]),n=c.path==='rotation'?4:3,V=c.vals,a=i*n,b=j*n;
    if(c.path==='rotation'){let ax=V[a],ay=V[a+1],az=V[a+2],aw=V[a+3],bx=V[b],by=V[b+1],bz=V[b+2],bw=V[b+3];let d=ax*bx+ay*by+az*bz+aw*bw;if(d<0){bx=-bx;by=-by;bz=-bz;bw=-bw}
     const q=[ax+(bx-ax)*f,ay+(by-ay)*f,az+(bz-az)*f,aw+(bw-aw)*f],l=Math.hypot(...q)||1;loc[c.node].r=q.map(v=>v/l)}
    else{const v=[V[a]+(V[b]-V[a])*f,V[a+1]+(V[b+1]-V[a+1])*f,V[a+2]+(V[b+2]-V[a+2])*f];if(c.path==='translation')loc[c.node].t=v;else loc[c.node].s=v}}}
  const world=new Array(nodes.length);
  for(const i of this.order){const n=nodes[i],l=n.m?new Float32Array(n.m):M.trs(loc[i].t,loc[i].r,loc[i].s);world[i]=n.p>=0&&world[n.p]?M.mul(world[n.p],l):l}
  const invMesh=M.inv(world[this.meshNode]||M.id());
  for(let k=0;k<this.joints.length;k++){const jw=world[this.joints[k]];const ib=this.ibm.subarray(k*16,k*16+16);this.jm.set(M.mul(invMesh,M.mul(jw,ib)),k*16)}}
 /* opts:{anim,time,yaw,pitch,rim:[r,g,b],flash} */
 render(o){
  if(!this.ready)return null;const gl=this.gl;
  this.pose(o.anim,o.time||0);
  gl.viewport(0,0,this.w,this.h);gl.clearColor(0,0,0,0);gl.clearDepth(1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);
  gl.useProgram(this.pr);
  const view=M.mul(M.rotX(o.pitch===undefined?-.38:o.pitch),M.mul(M.rotY(o.yaw||0),M.move(0,-.85,0)));
  const ar=this.w/this.h,hh=1.1,proj=M.ortho(-hh*ar,hh*ar,-hh,hh,-6,6);
  gl.uniformMatrix4fv(this.u.uView,false,view);gl.uniformMatrix4fv(this.u.uProj,false,proj);gl.uniformMatrix4fv(this.u.uJ,false,this.jm);
  const r=o.rim||[.3,.5,1];gl.uniform3f(this.u.uRim,r[0],r[1],r[2]);gl.uniform1f(this.u.uFlash,o.flash||0);
  [this.tBase,this.tNorm,this.tMR].forEach((t,i)=>{gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,t)});
  gl.uniform1i(this.u.tBase,0);gl.uniform1i(this.u.tNorm,1);gl.uniform1i(this.u.tMR,2);
  gl.bindVertexArray(this.vao);gl.drawElements(gl.TRIANGLES,this.idxCount,this.idxType,this.idxOff);gl.bindVertexArray(null);
  return this.cv}
}
window.GLBModel=GLBModel;
})();
