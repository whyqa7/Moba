# Legendas Nusantara: Rise of Myths
MOBA 5v5 (3 lane, menara, minion, Nexus) dengan 9 hero legenda Nusantara. Dibangun dengan HTML5 Canvas + Capacitor.

## Cara rilis APK lewat GitHub Actions
1. Buat repo baru di GitHub, upload **semua isi ZIP ini** (termasuk folder `.github`).
2. Rilis lewat salah satu cara:
   - **Tag:** `git tag v1.0.0 && git push origin v1.0.0`
   - **Manual:** tab **Actions** → *Build & Release APK* → **Run workflow**
3. Tunggu ±5-8 menit. APK muncul di tab **Releases** (juga di *Artifacts* run tersebut).
4. Pastikan **Settings → Actions → General → Workflow permissions** = *Read and write permissions*.

## Main di browser (tes cepat)
Buka `www/index.html` di Chrome. Kontrol: WASD gerak, J serang, U/I/O skill, B toko.

## Kontrol HP
Joystick kiri (muncul di mana pun disentuh) · ⚔️ serang (tahan) · 3 tombol skill · 🛒 toko.

## Catatan
- APK yang dihasilkan ditandatangani debug key: bisa langsung diinstall, tapi belum untuk Play Store.
- Ganti aset/hero: edit `www/game.js` (array `HEROES`) dan gambar di `www/img/`.
- Karakter hanya 9 (kartu hero), sisa slot bot diisi hero yang diulang.

## Hero 3D (GLB)
- `www/glb.js` = pemuat/renderer GLB mini (WebGL2, skinning + animasi), tanpa library luar.
- Hero Arakh memakai `www/models/arakh.glb` (animasi *Running* dan *Walking*).
- Tambah hero 3D lain: taruh `.glb` di `www/models/`, lalu di `www/game.js` set `HEROES.find(h=>h.id==='ID').glb='models/FILE.glb'`.
  Nama animasi yang dipakai: `Running` (bergerak) dan `Walking` (diam). Kalau WebGL2 tidak ada, game otomatis memakai sprite 2D.
- Model dari paket gratis Meshy berlisensi CC BY 4.0: cantumkan kredit Meshy bila game dirilis.
