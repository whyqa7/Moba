(()=>{
'use strict';
const $=id=>document.getElementById(id);
const cv=$('game'),ctx=cv.getContext('2d');
const mm=$('minimap'),mctx=mm.getContext('2d');
const MAPW=3600,MAPH=2400, TEAMC=['#3a8dff','#ff4b4b'];
let W=innerWidth,H=innerHeight,DPR=1,zoom=1;
function resize(){DPR=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;cv.width=W*DPR;cv.height=H*DPR;zoom=1;}
addEventListener('resize',resize);resize();
try{const SB=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.StatusBar;if(SB)SB.hide();}catch(e){}
document.addEventListener('contextmenu',e=>e.preventDefault());

const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const rand=(a,b)=>a+Math.random()*(b-a);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

/* ---------- DATA HERO ---------- */
const HEROES=[
{id:'gajahmada',name:'Gajah Mada',role:'Tank',color:'#d4a017',hp:2600,atk:62,rng:90,spd:160,as:.9,sk:[
 {n:'Tameng Palapa',t:'shield',cd:9,v:450,d:4,ic:'🛡️'},
 {n:'Hentak Bumi',t:'aoe',cd:7,dmg:210,r:170,stun:1,ic:'💥'},
 {n:'Serbuan Majapahit',t:'dash',cd:10,dmg:250,range:320,ic:'🐘'}]},
{id:'kiansantang',name:'Kian Santang',role:'Mage / Support',color:'#fff3b0',hp:1800,atk:55,rng:290,spd:165,as:.9,sk:[
 {n:'Panah Cahaya',t:'shot',cd:5,dmg:260,range:560,slow:1.5,ic:'✨'},
 {n:'Berkah Cahaya',t:'heal',cd:10,v:320,r:320,ic:'💛'},
 {n:'Ledakan Terang',t:'aoe',cd:8,dmg:240,r:190,ic:'🌟'}]},
{id:'nyai',name:'Nyai Roro Kidul',role:'Mage',color:'#20c9a0',hp:1750,atk:58,rng:290,spd:160,as:.9,sk:[
 {n:'Ombak Pasang',t:'shot',cd:6,dmg:280,range:600,slow:2,ic:'🌊'},
 {n:'Pusaran Laut',t:'aoe',cd:8,dmg:200,r:200,slow:2,ic:'🌀'},
 {n:'Berkah Samudra',t:'heal',cd:12,v:350,r:300,ic:'💧'}]},
{id:'prabu',name:'Prabu Siliwangi',role:'Fighter',color:'#c99a2e',hp:2300,atk:80,rng:100,spd:170,as:1,sk:[
 {n:'Cakar Singa',t:'dash',cd:8,dmg:260,range:300,ic:'🦁'},
 {n:'Tombak Pajajaran',t:'shot',cd:6,dmg:300,range:520,ic:'🔱'},
 {n:'Raungan Harimau',t:'aoe',cd:11,dmg:230,r:170,stun:.8,ic:'🐯'}]},
{id:'sipitung',name:'Si Pitung',role:'Assassin',color:'#d33',hp:1750,atk:88,rng:85,spd:185,as:1.15,sk:[
 {n:'Golok Kilat',t:'dash',cd:6,dmg:280,range:340,ic:'⚡'},
 {n:'Pukulan Jawara',t:'aoe',cd:5,dmg:180,r:130,ic:'👊'},
 {n:'Lincah Jawara',t:'haste',cd:9,d:3,ic:'💨'}]},
{id:'kenarok',name:'Ken Arok',role:'Assassin',color:'#7a5cff',hp:1700,atk:90,rng:90,spd:180,as:1.1,sk:[
 {n:'Tusuk Bayangan',t:'dash',cd:7,dmg:300,range:360,ic:'🗡️'},
 {n:'Keris Mpu Gandring',t:'shot',cd:5,dmg:270,range:450,ic:'🔪'},
 {n:'Darah Raja',t:'aoe',cd:10,dmg:260,r:150,ic:'🩸'}]},
{id:'calonarang',name:'Calon Arang',role:'Mage',color:'#9b30d0',hp:1650,atk:62,rng:300,spd:160,as:.9,sk:[
 {n:'Sihir Hitam',t:'shot',cd:6,dmg:300,range:600,ic:'🔮'},
 {n:'Kutukan',t:'aoe',cd:9,dmg:220,r:210,slow:2,ic:'☠️'},
 {n:'Tumbal',t:'heal',cd:14,v:400,r:120,ic:'🕯️'}]},
{id:'jakatarub',name:'Jaka Tarub',role:'Marksman',color:'#4aa86a',hp:1700,atk:85,rng:340,spd:170,as:1.2,sk:[
 {n:'Panah Pelangi',t:'shot',cd:5,dmg:280,range:700,ic:'🏹'},
 {n:'Selendang Bidadari',t:'haste',cd:10,d:3,ic:'🧣'},
 {n:'Hujan Panah',t:'aoe',cd:9,dmg:240,r:200,ic:'🌧️'}]},
{id:'tjoet',name:'Tjoet Nyak Dhien',role:'Marksman / Fighter',color:'#e04a3a',hp:1950,atk:80,rng:200,spd:175,as:1.05,sk:[
 {n:'Rencong Aceh',t:'dash',cd:7,dmg:240,range:300,ic:'🗡️'},
 {n:'Serangan Gerilya',t:'shot',cd:5,dmg:260,range:520,ic:'🎯'},
 {n:'Semangat Aceh',t:'shield',cd:10,v:350,d:4,ic:'🔥'}]}

,{id:'gatotkaca',name:'Gatotkaca',role:'Fighter / Terbang',color:'#d4a017',hp:2100,atk:82,rng:95,spd:185,as:1.05,sk:[
 {n:'Terjang Sayap Baja',t:'dash',cd:7,dmg:280,range:380,ic:'🦅'},
 {n:'Kuku Pancanaka',t:'aoe',cd:8,dmg:240,r:160,stun:.6,ic:'⚡'},
 {n:'Otot Kawat Tulang Besi',t:'shield',cd:11,v:380,d:4,ic:'💪'}]},
{id:'kendedes',name:'Ken Dedes',role:'Mage / Support',color:'#c99a2e',hp:1750,atk:56,rng:280,spd:160,as:.9,sk:[
 {n:'Cahaya Nareswari',t:'shot',cd:5,dmg:260,range:560,slow:1.5,ic:'🌟'},
 {n:'Berkah Singhasari',t:'heal',cd:10,v:380,r:340,ic:'💛'},
 {n:'Selendang Pelindung',t:'shield',cd:11,v:400,d:4,ic:'🛡️'}]},
{id:'wijaya',name:'Raden Wijaya',role:'Fighter',color:'#b8862d',hp:2400,atk:78,rng:100,spd:170,as:1,sk:[
 {n:'Tebasan Majapahit',t:'dash',cd:8,dmg:270,range:320,ic:'⚔️'},
 {n:'Keris Pusaka',t:'shot',cd:6,dmg:280,range:480,ic:'🗡️'},
 {n:'Zirah Emas',t:'shield',cd:10,v:450,d:4,ic:'👑'}]},
{id:'arakh',name:'Arakh Sang Badai',role:'Tank / Fighter',color:'#3a8dff',hp:2500,atk:75,rng:95,spd:165,as:.95,sk:[
 {n:'Thunderbrand',t:'shot',cd:6,dmg:300,range:560,stun:.5,ic:'🪓'},
 {n:'Stormshield',t:'shield',cd:9,v:500,d:4,ic:'🌩️'},
 {n:'Hantaman Badai',t:'aoe',cd:9,dmg:260,r:180,stun:.8,ic:'⛈️'}]}
];
const SPR=['nyai','sipitung','gatotkaca','kendedes','wijaya','arakh'];
HEROES.sort((a,b)=>SPR.includes(b.id)-SPR.includes(a.id));
HEROES.forEach(h=>{h.img=new Image();h.img.src='img/h_'+h.id+'.png';
 if(SPR.includes(h.id)){h.spr={};['front','back','side'].forEach(v=>{const i=new Image();i.src='img/s_'+h.id+'_'+v+'.png';h.spr[v]=i})}});
const ITEMS=[
 {n:'Keris Pusaka (+18 Serangan)',ic:'🗡️',cost:400,fn:h=>h.bonusAtk+=18},
 {n:'Zirah Majapahit (+380 HP)',ic:'🛡️',cost:400,fn:h=>h.bonusHp+=380},
 {n:'Sepatu Garuda (+15 Speed)',ic:'👟',cost:350,fn:h=>h.bonusSpd+=15}];

/* ---------- PETA & LANE ---------- */
const BASE=[{x:330,y:2070},{x:3270,y:330}];
const LANES=[
 [{x:330,y:2070},{x:330,y:330},{x:3270,y:330}],
 [{x:330,y:2070},{x:1800,y:1200},{x:3270,y:330}],
 [{x:330,y:2070},{x:3270,y:2070},{x:3270,y:330}]];
const RIVER=[{x:800,y:500},{x:1800,y:1200},{x:2700,y:1830}];
const POOLS=[{x:1150,y:745,kind:'turtle'},{x:2450,y:1655,kind:'lord'}];
const PATHS=[LANES,LANES.map(p=>p.slice().reverse().map(q=>({x:q.x,y:q.y})))];
const cumOf=p=>{const c=[0];for(let i=1;i<p.length;i++)c.push(c[i-1]+dist(p[i-1],p[i]));return c};
const CUM=PATHS.map(t=>t.map(cumOf));
const LEN=CUM[0].map(c=>c[c.length-1]);
function ptAt(p,d){for(let i=1;i<p.length;i++){const l=dist(p[i-1],p[i]);if(d<=l){const t=d/l;return{x:p[i-1].x+(p[i].x-p[i-1].x)*t,y:p[i-1].y+(p[i].y-p[i-1].y)*t}}d-=l}return{x:p[p.length-1].x,y:p[p.length-1].y}}
function distSeg(p,a,b){const dx=b.x-a.x,dy=b.y-a.y;const t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy),0,1);return Math.hypot(p.x-(a.x+dx*t),p.y-(a.y+dy*t))}
// dekorasi & camp jungle (peta mirip Land of Dawn)
const dPoly=(p,L)=>{let m=1e9;for(let i=1;i<L.length;i++)m=Math.min(m,distSeg(p,L[i-1],L[i]));return m};
const dLanes=p=>Math.min(dPoly(p,LANES[0]),dPoly(p,LANES[1]),dPoly(p,LANES[2]));
let sd=7;const R=()=>(sd=(sd*16807)%2147483647)/2147483647;
const okJ=(p,ml,mr)=>dLanes(p)>ml&&dPoly(p,RIVER)>mr&&dist(p,BASE[0])>340&&dist(p,BASE[1])>340&&POOLS.every(q=>dist(p,q)>230);
const CAMPS=[],TREES=[],ROCKS=[],BUSHES=[];
for(let n=0;n<6000&&CAMPS.length<8;n++){const p={x:200+R()*1500,y:200+R()*2000};
 if(!okJ(p,230,230)||dist(p,{x:1800,y:1200})<320||CAMPS.some(c=>dist(c,p)<420))continue;CAMPS.push({x:p.x,y:p.y,kind:'small'})}
CAMPS.slice().forEach(c=>CAMPS.push({x:MAPW-c.x,y:MAPH-c.y,kind:'small'}));
POOLS.forEach(q=>CAMPS.push({x:q.x,y:q.y,kind:q.kind}));
for(let n=0;n<9000&&TREES.length<280;n++){const p={x:-330+R()*(MAPW+660),y:-330+R()*(MAPH+660)};
 if(p.x>-170&&p.x<MAPW+170&&p.y>-170&&p.y<MAPH+170)continue;TREES.push({x:p.x,y:p.y,r:22+R()*22,v:'p'})}
for(let n=0;n<4000&&TREES.length<340;n++){const p={x:200+R()*(MAPW-400),y:200+R()*(MAPH-400)};
 if(!okJ(p,170,150)||CAMPS.some(c=>dist(c,p)<170))continue;TREES.push({x:p.x,y:p.y,r:22+R()*16,v:'p'})}
const edge=(x,y)=>{const p={x,y};if(dLanes(p)>105&&dist(p,BASE[0])>300&&dist(p,BASE[1])>300)TREES.push({x,y,r:24+R()*12,v:'b'})};
for(let x=110;x<MAPW-80;x+=130){edge(x,55+R()*80);edge(x,MAPH-55-R()*80)}
for(let y=110;y<MAPH-80;y+=130){edge(55+R()*80,y);edge(MAPW-55-R()*80,y)}
for(let n=0;n<5000&&ROCKS.length<150;n++){const p={x:60+R()*(MAPW-120),y:60+R()*(MAPH-120)};
 if(!okJ(p,150,110)||CAMPS.some(c=>dist(c,p)<130))continue;ROCKS.push({x:p.x,y:p.y,r:18+R()*26,sh:R()})}
for(let n=0;n<5000&&BUSHES.length<150;n++){const p={x:60+R()*(MAPW-120),y:60+R()*(MAPH-120)};
 if(!okJ(p,120,90)||CAMPS.some(c=>dist(c,p)<100))continue;BUSHES.push({x:p.x,y:p.y,r:16+R()*14,f:R()<.55?['#ff9a3c','#ff6fae','#c67bff','#ffe36b'][(R()*4)|0]:null})}

/* ---------- STATE ---------- */
let units=[],proj=[],fx=[],uid=0,G=null;
const input={mx:0,my:0,atk:false,sk:[false,false,false],keys:{}};
function mk(o){o.id=++uid;o.maxhp=o.hp;o.stun=0;o.slow=0;o.haste=0;o.shield=0;o.shieldT=0;o.acd=0;o.dead=false;units.push(o);return o}
const WT={monster:{hero:0},hero:{hero:-80,minion:0,monster:10,tower:40,nexus:40},minion:{minion:-50,hero:30,tower:60,nexus:60},tower:{minion:-100,hero:0},nexus:{minion:-100,hero:0}};

function stats(h){const d=h.def,f=h.lv-1;const mh=d.hp*(1+.12*f)+h.bonusHp;h.hp+=mh-h.maxhp;h.maxhp=mh;h.atk=d.atk*(1+.1*f)+h.bonusAtk;h.spd=d.spd+h.bonusSpd}
function makeHero(def,team,player,lane,slot){
 const b=BASE[team],s=team?-1:1;
 const h=mk({type:'hero',def,team,x:b.x+s*(70+slot*10),y:b.y-s*(50+slot*14),r:26,hp:def.hp,atk:def.atk,rng:def.rng,spd:def.spd,as:def.as,ranged:def.rng>150,
  lv:1,xp:0,gold:300,k:0,d:0,player,bot:!player,lane,slot,respawn:0,scd:[0,0,0],face:0,bonusAtk:0,bonusHp:0,bonusSpd:0,dash:null,retreat:false,path:PATHS[team][lane]});
 return h}
function shuffle(a){a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}

function startGame(def){
 units=[];proj=[];fx=[];uid=0;
 G={time:0,wave:3,q:[],score:[0,0],over:false,player:null};
 for(const c of CAMPS){c.mon=null;c.next=c.kind==='small'?8:c.kind==='turtle'?70:240}
 for(let team=0;team<2;team++){const inner=[];
  for(let lane=0;lane<3;lane++){const path=PATHS[team][lane],L=LEN[lane];
   const mkT=(idx,f)=>{const p=ptAt(path,L*f);return mk({type:'tower',team,lane,idx,x:p.x,y:p.y,r:34,hp:2800,atk:110,rng:300,as:.9,ranged:true})};
   const outer=mkT(0,.30),inn=mkT(1,.12);inn.prev=outer;inner.push(inn)}
  const n=mk({type:'nexus',team,x:BASE[team].x,y:BASE[team].y,r:70,hp:5500,atk:130,rng:340,as:.9,ranged:true});n.guards=inner}
 const pool=shuffle(HEROES.filter(h=>h!==def));let pi=0;const take=()=>pool[(pi++)%pool.length];
 G.player=makeHero(def,0,true,1,0);
 [0,2,1,1].forEach((l,i)=>makeHero(take(),0,false,l,i+1));
 [0,2,1,1,0].forEach((l,i)=>makeHero(take(),1,false,l,i));
 const sk=$('btns').querySelectorAll('.sk');
 sk.forEach((b,i)=>{b.innerHTML='<span>'+def.sk[i].ic+'</span><b></b>'});
 buildShop();toast('Hancurkan Nexus musuh! 🔥');
}

/* ---------- LOGIKA ---------- */
function targetable(u){
 if(u.dead)return false;
 if(u.type==='tower')return !u.prev||u.prev.dead;
 if(u.type==='nexus')return u.guards.some(g=>g.dead);
 return true}
function pickTarget(me,range){
 const w=WT[me.type];let best=null,bs=1e9;
 for(const u of units){
  if(u.team===me.team||u.dead||!targetable(u))continue;
  if(me.bot&&u.type==='monster')continue;
  const wt=w[u.type];if(wt===undefined)continue;
  const d=dist(me,u)-u.r;if(d>range)continue;
  if(me.bot&&(u.type==='tower'||u.type==='nexus')){let ok=false;
   for(const m of units)if(m.type==='minion'&&m.team===me.team&&!m.dead&&dist(m,u)<380){ok=true;break}
   if(!ok)continue}
  const sc=d+wt;if(sc<bs){bs=sc;best=u}}
 return best}
function moveDir(u,dx,dy,dt){
 if(u.stun>0)return;const l=Math.hypot(dx,dy);if(l<.001)return;
 const mag=Math.min(1,l),sp=u.spd*(u.slow>0?.55:1)*(u.haste>0?1.35:1);
 u.x=clamp(u.x+dx/l*mag*sp*dt,30,MAPW-30);u.y=clamp(u.y+dy/l*mag*sp*dt,30,MAPH-30);u.face=Math.atan2(dy,dx);u.mv=G?G.time:0}
function moveTo(u,p,dt){const l=Math.hypot(p.x-u.x,p.y-u.y);if(l>1)moveDir(u,(p.x-u.x)/l,(p.y-u.y)/l,dt)}
function tryAttack(u,t){
 if(u.acd>0||u.stun>0)return;u.acd=1/u.as;u.atkT=G.time;u.face=Math.atan2(t.y-u.y,t.x-u.x);
 if(u.ranged)proj.push({homing:true,x:u.x,y:u.y,tgt:t,spd:750,dmg:u.atk,team:u.team,from:u,color:u.def?u.def.color:TEAMC[u.team],r:u.type==='hero'?6:5});
 else{dmg(u,t,u.atk);fx.push({k:'ring',x:t.x,y:t.y,r:8,max:30,life:.2,t0:.2,color:'#fff'})}}
function dmg(src,t,a){
 if(t.dead||!targetable(t))return;
 if(t.shield>0){const s=Math.min(t.shield,a);t.shield-=s;a-=s}
 if(a<=0)return;t.hp-=a;
 if((src&&src.player)||t.player)if(fx.length<150)fx.push({k:'txt',x:t.x+rand(-10,10),y:t.y-t.r,txt:Math.round(a),life:.7,t0:.7,color:t.team?'#fff':'#ff8a8a'});
 if(t.type==='monster'&&src&&src.type==='hero')t.aggro=src;
 if(t.hp<=0)kill(src,t)}
function grantXP(h,x){h.xp+=x;while(h.xp>=h.lv*200&&h.lv<12){h.xp-=h.lv*200;h.lv++;stats(h);h.hp=Math.min(h.maxhp,h.hp+h.maxhp*.15);if(h.player)toast('Naik level '+h.lv+'! ⬆️')}}
function nearHeroes(t,r){return units.filter(h=>h.type==='hero'&&h.team!==t.team&&!h.dead&&dist(h,t)<r)}
function kill(src,t){
 t.dead=true;
 if(t.type==='hero'){
  t.d++;t.respawn=5+t.lv*1.5;G.score[1-t.team]++;t.dash=null;
  const kl=src&&src.type==='hero'?src:null;
  for(const h of nearHeroes(t,700)){if(h===kl){h.k++;h.gold+=300;grantXP(h,200)}else{h.gold+=100;grantXP(h,120)}}
  fx.push({k:'ring',x:t.x,y:t.y,r:10,max:90,life:.5,t0:.5,color:'#fff'});
  if(t.player)toast('Kamu gugur! 💀');
  else if(kl&&kl.player)toast('Kamu mengalahkan '+t.def.name+'! ⚔️');
 }else if(t.type==='minion'){for(const h of nearHeroes(t,650)){h.gold+=22;grantXP(h,45)}}
 else if(t.type==='tower'){for(const h of units)if(h.type==='hero'&&h.team!==t.team){h.gold+=180;grantXP(h,100)}
  toast(t.team===0?'Menara kita hancur! 🏚️':'Menara musuh hancur! 🔥');fx.push({k:'ring',x:t.x,y:t.y,r:20,max:160,life:.7,t0:.7,color:'#ffb347'})}
 else if(t.type==='monster'){
  const c=t.camp;c.mon=null;c.next=G.time+(t.kind==='small'?55:t.kind==='turtle'?120:180);
  const tm=src&&src.type==='hero'?src.team:-1;
  if(t.kind==='small'){if(tm>=0)for(const h of units)if(h.type==='hero'&&h.team===tm&&!h.dead&&dist(h,t)<650){const f=h===src?1:.5;h.gold+=t.gold*f;grantXP(h,t.xp*f)}}
  else if(tm>=0){for(const h of units)if(h.type==='hero'&&h.team===tm){h.gold+=t.gold;grantXP(h,t.xp)}
   if(G.player.team===tm)toast(t.kind==='lord'?'Lord dikalahkan! +emas tim 👑':'Kura-kura dikalahkan! +emas tim 🐢')}}
 else if(t.type==='nexus'){endGame(1-t.team)}}
function endGame(win){G.over=true;$('over').classList.remove('hidden');
 const p=G.player;$('otitle').textContent=win===0?'KEMENANGAN! 🏆':'KEKALAHAN 💀';
 $('otitle').style.color=win===0?'#ffd56a':'#ff6b6b';
 $('ostat').textContent='K/D: '+p.k+'/'+p.d+' · Level '+p.lv+' · Skor '+G.score[0]+' - '+G.score[1]}

function cast(h,i,tgt){
 const s=h.def.sk[i];if(h.dead||h.stun>0||h.scd[i]>0||h.dash)return;
 const lm=1+.1*(h.lv-1);
 let ang=h.face;const reach=(s.range||s.r||250)+80;
 const t=(tgt&&!tgt.dead)?tgt:pickTarget(h,reach);
 if(t)ang=Math.atan2(t.y-h.y,t.x-h.x);h.face=ang;
 const c=Math.cos(ang),sn=Math.sin(ang);h.scd[i]=s.cd;h.atkT=G.time;
 switch(s.t){
  case 'shot':proj.push({x:h.x,y:h.y,vx:c,vy:sn,spd:850,dist:0,max:s.range,dmg:s.dmg*lm,team:h.team,r:24,slow:s.slow,stun:s.stun,hit:new Set(),color:h.def.color,from:h});break;
  case 'aoe':fx.push({k:'ring',x:h.x,y:h.y,r:10,max:s.r,life:.35,t0:.35,color:h.def.color});
   for(const u of units){if(u.team===h.team||u.dead||!targetable(u)||dist(h,u)>s.r+u.r)continue;dmg(h,u,s.dmg*lm);if(s.stun)u.stun=Math.max(u.stun,s.stun);if(s.slow)u.slow=Math.max(u.slow,s.slow)}break;
  case 'dash':h.dash={dx:c,dy:sn,left:s.range,dmg:s.dmg*lm,hit:new Set()};break;
  case 'shield':h.shield=s.v*lm;h.shieldT=s.d;fx.push({k:'ring',x:h.x,y:h.y,r:10,max:60,life:.4,t0:.4,color:'#fff'});break;
  case 'heal':fx.push({k:'ring',x:h.x,y:h.y,r:10,max:s.r,life:.5,t0:.5,color:'#7dff9a'});
   for(const u of units)if(u.type==='hero'&&u.team===h.team&&!u.dead&&dist(u,h)<=s.r)u.hp=Math.min(u.maxhp,u.hp+s.v*lm);break;
  case 'haste':h.haste=s.d;fx.push({k:'ring',x:h.x,y:h.y,r:10,max:50,life:.3,t0:.3,color:'#9cf'});break}}

function dashTick(h,dt){
 const D=h.dash,st=Math.min(900*dt,D.left);
 h.x=clamp(h.x+D.dx*st,30,MAPW-30);h.y=clamp(h.y+D.dy*st,30,MAPH-30);D.left-=st;
 fx.push({k:'ring',x:h.x,y:h.y,r:h.r,max:h.r+10,life:.15,t0:.15,color:h.def.color});
 for(const u of units){if(u.team===h.team||u.dead||D.hit.has(u.id)||u.type==='tower'||u.type==='nexus')continue;
  if(dist(h,u)<h.r+u.r+14){D.hit.add(u.id);dmg(h,u,D.dmg);u.stun=Math.max(u.stun,.4)}}
 if(D.left<=0)h.dash=null}

function botSkills(h,t,d){
 const pct=h.hp/h.maxhp;
 for(let i=0;i<3;i++){const s=h.def.sk[i];if(h.scd[i]>0)continue;let go=false;
  switch(s.t){
   case 'shot':go=t.type==='hero'&&d<s.range*.85;break;
   case 'dash':go=t.type==='hero'&&d<s.range*.8&&d>60;break;
   case 'aoe':{let n=0;for(const u of units)if(u.team!==h.team&&!u.dead&&u.type!=='tower'&&u.type!=='nexus'&&dist(h,u)<s.r)n+=u.type==='hero'?3:1;go=n>=3;break}
   case 'heal':case 'shield':go=pct<.6&&d<400;break;
   case 'haste':go=t.type==='hero';break}
  if(go)cast(h,i,t)}}
function botAI(h,dt){
 const own=BASE[h.team],pct=h.hp/h.maxhp;
 for(const it of ITEMS)if(h.gold>=it.cost+150&&Math.random()<.02){h.gold-=it.cost;it.fn(h);stats(h)}
 if(pct<.28)h.retreat=true;if(h.retreat&&pct>.8)h.retreat=false;
 if(h.retreat){for(let i=0;i<3;i++){const s=h.def.sk[i];if(h.scd[i]<=0&&(s.t==='heal'||s.t==='shield'||s.t==='haste'))cast(h,i)}moveTo(h,own,dt);return}
 const t=pickTarget(h,Math.max(h.rng+60,380));
 if(t){const d=dist(h,t)-t.r;
  if(d>h.rng-10)moveTo(h,t,dt);
  if(d<=h.rng)tryAttack(h,t);
  botSkills(h,t,d);return}
 let front=-1;
 for(const m of units)if(m.type==='minion'&&m.team===h.team&&m.lane===h.lane&&!m.dead){const pr=CUM[m.team][m.lane][m.wi]-dist(m,m.path[m.wi]);if(pr>front)front=pr}
 const want=front>=0?Math.max(200,front-90-h.slot*35):200;
 const p=ptAt(h.path,want);if(dist(h,p)>35)moveTo(h,p,dt)}
function playerCtl(h,dt){
 let dx=input.mx,dy=input.my;const k=input.keys;
 if(k.a||k.arrowleft)dx-=1;if(k.d||k.arrowright)dx+=1;if(k.w||k.arrowup)dy-=1;if(k.s||k.arrowdown)dy+=1;
 if(dx||dy)moveDir(h,dx,dy,dt);
 if(input.atk||k.j){const t=pickTarget(h,h.rng);if(t)tryAttack(h,t)}
 for(let i=0;i<3;i++)if(input.sk[i]){input.sk[i]=false;cast(h,i)}}
function heroTick(h,dt){
 if(h.dead){h.respawn-=dt;if(h.respawn<=0){h.dead=false;h.hp=h.maxhp;const b=BASE[h.team];h.x=b.x+(h.team?-70:70);h.y=b.y-(h.team?-50:50);h.retreat=false;h.shield=0}return}
 h.gold+=2*dt;for(let i=0;i<3;i++)if(h.scd[i]>0)h.scd[i]-=dt;
 if(dist(h,BASE[h.team])<260)h.hp=Math.min(h.maxhp,h.hp+h.maxhp*.06*dt);else h.hp=Math.min(h.maxhp,h.hp+h.maxhp*.004*dt);
 if(h.dash){dashTick(h,dt);return}
 if(h.player)playerCtl(h,dt);else botAI(h,dt)}
function minionTick(m,dt){
 const t=pickTarget(m,m.ranged?230:160);
 if(t){const d=dist(m,t)-t.r;if(d>m.rng-4)moveTo(m,t,dt);else tryAttack(m,t);return}
 const wp=m.path[m.wi];if(dist(m,wp)<45&&m.wi<m.path.length-1)m.wi++;moveTo(m,m.path[m.wi],dt)}
function structTick(s){if(s.acd>0)return;const t=pickTarget(s,s.rng);if(t)tryAttack(s,t)}
function spawnMonster(c){const sc=1+G.time/700,k=c.kind;
 const S={small:{hp:650,atk:34,r:20,rng:55,gold:70,xp:110,spd:125},turtle:{hp:2600,atk:70,r:34,rng:70,gold:200,xp:160,spd:100},lord:{hp:5200,atk:120,r:44,rng:80,gold:320,xp:300,spd:105}}[k];
 c.mon=mk({type:'monster',team:2,kind:k,x:c.x,y:c.y,home:{x:c.x,y:c.y},camp:c,r:S.r,hp:S.hp*sc,atk:S.atk*sc,rng:S.rng,spd:S.spd,as:.9,ranged:false,gold:S.gold,xp:S.xp,aggro:null})}
function monsterTick(m,dt){
 let t=m.aggro&&!m.aggro.dead&&dist(m,m.home)<650?m.aggro:null;
 if(!t){m.aggro=null;t=dist(m,m.home)<300?pickTarget(m,210):null}
 if(t){const d=dist(m,t)-t.r;if(d>m.rng)moveTo(m,t,dt);else tryAttack(m,t)}
 else{if(dist(m,m.home)>8)moveTo(m,m.home,dt);m.hp=Math.min(m.maxhp,m.hp+m.maxhp*.12*dt)}}
function spawnMinion(team,lane,ranged){
 const path=PATHS[team][lane],sc=1+G.time/900;
 mk({type:'minion',team,lane,x:path[0].x+rand(-30,30),y:path[0].y+rand(-30,30),r:ranged?12:15,hp:(ranged?300:480)*sc,atk:(ranged?34:26)*sc,rng:ranged?190:42,spd:ranged?100:105,as:ranged?.9:1,ranged,wi:1,path})}

function update(dt){
 if(!G||G.over)return;
 G.time+=dt;G.wave-=dt;
 if(G.wave<=0){G.wave=24;for(let tm=0;tm<2;tm++)for(let l=0;l<3;l++)for(let k=0;k<4;k++)G.q.push({t:G.time+k*.8,team:tm,lane:l,r:k===3})}
 for(let i=G.q.length-1;i>=0;i--)if(G.q[i].t<=G.time){const q=G.q[i];spawnMinion(q.team,q.lane,q.r);G.q.splice(i,1)}
 for(const c of CAMPS)if(!c.mon&&G.time>=c.next)spawnMonster(c);
 for(const u of units){
  if(u.dead&&u.type!=='hero')continue;
  if(!u.dead){u.acd-=dt;if(u.stun>0)u.stun-=dt;if(u.slow>0)u.slow-=dt;if(u.haste>0)u.haste-=dt;if(u.shieldT>0){u.shieldT-=dt;if(u.shieldT<=0)u.shield=0}}
  if(u.type==='hero')heroTick(u,dt);else if(u.type==='minion')minionTick(u,dt);else if(u.type==='monster')monsterTick(u,dt);else structTick(u)}
 for(let i=proj.length-1;i>=0;i--){const p=proj[i];let rm=false;
  if(p.homing){if(p.tgt.dead)rm=true;else{const dx=p.tgt.x-p.x,dy=p.tgt.y-p.y,d=Math.hypot(dx,dy)||1,st=p.spd*dt;
    if(d<=st+p.tgt.r*.5){dmg(p.from,p.tgt,p.dmg);rm=true}else{p.x+=dx/d*st;p.y+=dy/d*st}}}
  else{const st=p.spd*dt;p.x+=p.vx*st;p.y+=p.vy*st;p.dist+=st;
   for(const u of units){if(u.team===p.team||u.dead||p.hit.has(u.id)||!targetable(u))continue;
    if(Math.hypot(u.x-p.x,u.y-p.y)<u.r+p.r){p.hit.add(u.id);dmg(p.from,u,p.dmg);if(p.slow)u.slow=Math.max(u.slow,p.slow);if(p.stun)u.stun=Math.max(u.stun,p.stun);rm=true;break}}
   if(p.dist>=p.max)rm=true}
  if(rm)proj.splice(i,1)}
 for(let i=fx.length-1;i>=0;i--){fx[i].life-=dt;if(fx[i].life<=0)fx.splice(i,1)}
 units=units.filter(u=>!u.dead||u.type==='hero');
 hud(dt)}

/* ---------- HUD ---------- */
let hudT=0,toastT=0;
function toast(m){$('toast').textContent=m;toastT=2.2}
function buildShop(){const box=$('items');box.innerHTML='';
 ITEMS.forEach((it,i)=>{const b=document.createElement('button');b.id='it'+i;b.innerHTML='<span>'+it.ic+' '+it.n+'</span><b>'+it.cost+'</b>';
  b.onclick=()=>{const p=G.player;if(p.gold>=it.cost){p.gold-=it.cost;it.fn(p);stats(p);toast('Dibeli: '+it.n)}};box.appendChild(b)})}
function hud(dt){
 if(toastT>0){toastT-=dt;if(toastT<=0)$('toast').textContent=''}
 hudT-=dt;if(hudT>0)return;hudT=.1;const p=G.player;
 $('s0').textContent=G.score[0];$('s1').textContent=G.score[1];
 const m=Math.floor(G.time/60),s=Math.floor(G.time%60);$('timer').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
 $('pfill').style.width=(clamp(p.hp/p.maxhp,0,1)*100)+'%';$('ptxt').textContent=Math.ceil(Math.max(0,p.hp))+' / '+Math.ceil(p.maxhp);
 $('plv').textContent=p.def.name+' · Lv '+p.lv;$('pgold').textContent='💰 '+Math.floor(p.gold);
 for(let i=0;i<3;i++){const b=$('b_s'+i).querySelector('b');if(b)b.textContent=p.scd[i]>0?Math.ceil(p.scd[i]):''}
 ITEMS.forEach((it,i)=>{const b=$('it'+i);if(b)b.disabled=p.gold<it.cost});
 const r=$('respawn');if(p.dead){r.classList.remove('hidden');r.textContent='Bangkit dalam '+Math.ceil(p.respawn)+' dtk'}else r.classList.add('hidden')}

/* ---------- RENDER: kamera miring berperspektif (2.5D) ---------- */
const CYF=.62,TILT=.0007;let CX=0,CYc=0,ZM=1,VX=0,VF=0,VN=0,camInit=false;
function P(x,y,h){let dx=x-CX,dy=y-CYc;if(dy>1000)dy=1000;const k=1/(1-dy*TILT);return[W/2+dx*k*ZM,H*.58+dy*k*CYF*ZM-(h||0)*k*ZM,k*ZM]}
const inV=(x,y,m)=>Math.abs(x-CX)<VX+m&&y>CYc-VF-m&&y<CYc+VN+m;
function poly(pts,fill,stroke,lw){ctx.beginPath();for(let i=0;i<pts.length;i++)i?ctx.lineTo(pts[i][0],pts[i][1]):ctx.moveTo(pts[i][0],pts[i][1]);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw||1;ctx.stroke()}}
function ell(sx,sy,rx,fill,stroke,lw){ctx.beginPath();ctx.ellipse(sx,sy,rx,rx*CYF,0,0,7);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw||1;ctx.stroke()}}
function gEll(x,y,r,fill,stroke,lw){const p=P(x,y);ell(p[0],p[1],r*p[2],fill,stroke,(lw||1)*p[2])}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath()}
function bar(x,y,w,pct,col,hh){hh=hh||6;ctx.fillStyle='#000b';rr(x-w/2-1.5,y-1.5,w+3,hh+3,3);ctx.fill();ctx.fillStyle=col;rr(x-w/2,y,Math.max(0,w*clamp(pct,0,1)),hh,2);ctx.fill()}
const shade=(c,f)=>{const n=parseInt(c.slice(1),16);const r=clamp((n>>16)*f,0,255)|0,g=clamp(((n>>8)&255)*f,0,255)|0,b=clamp((n&255)*f,0,255)|0;return'rgb('+r+','+g+','+b+')'};
const GRASS=[];(()=>{let q=11;const r=()=>(q=(q*16807)%2147483647)/2147483647;for(let i=0;i<1500;i++)GRASS.push({x:r()*MAPW,y:r()*MAPH,c:r()<.14?['#ffd6e0','#fff3a0','#ffffff','#ffb36b','#d9b3ff'][i%5]:null,s:6+r()*8})})();
const MC=['#4f9bff','#ff5656'];

function drawGround(t){
 const T=160;
 const i0=Math.floor((CX-VX)/T),i1=Math.ceil((CX+VX)/T),j0=Math.floor((CYc-VF)/T),j1=Math.ceil((CYc+VN)/T);
 const cols=[['#3b7840','#417e44','#38723d'],['#468045','#4c874a','#427a43']];
 for(let i=i0;i<i1;i++)for(let j=j0;j<j1;j++){if(i<0||j<0||i>=MAPW/T||j>=MAPH/T)continue;
  const h=((i*73856093)^(j*19349663))>>>0;
  poly([P(i*T,j*T),P(i*T+T+1,j*T),P(i*T+T+1,j*T+T+1),P(i*T,j*T+T+1)],cols[(i+j)&1][h%3])}
 for(const g of GRASS){if(!inV(g.x,g.y,20))continue;const p=P(g.x,g.y);
  if(g.c){ctx.fillStyle=g.c;ctx.beginPath();ctx.arc(p[0],p[1]-2*p[2],2.4*p[2],0,7);ctx.fill()}
  else{ctx.strokeStyle='#245c2b';ctx.lineWidth=1.5*p[2];ctx.beginPath();ctx.moveTo(p[0]-3*p[2],p[1]);ctx.lineTo(p[0]-1*p[2],p[1]-g.s*p[2]);ctx.moveTo(p[0]+2*p[2],p[1]);ctx.lineTo(p[0]+3*p[2],p[1]-g.s*.8*p[2]);ctx.stroke()}}
}
function drawRiver(t){
 const hw=95;
 for(let i=1;i<RIVER.length;i++){const A=RIVER[i-1],B=RIVER[i],l=dist(A,B),ux=(B.x-A.x)/l,uy=(B.y-A.y)/l;
  for(const pass of [0,1]){const w=pass?hw:hw+16,nx=-uy*w,ny=ux*w;
   for(let q=0;q<l;q+=100){const e=Math.min(q+101,l),mx=A.x+ux*(q+50),my=A.y+uy*(q+50);if(!inV(mx,my,200))continue;
    const a={x:A.x+ux*q,y:A.y+uy*q},b={x:A.x+ux*e,y:A.y+uy*e};
    poly([P(a.x+nx,a.y+ny),P(b.x+nx,b.y+ny),P(b.x-nx,b.y-ny),P(a.x-nx,a.y-ny)],pass?(((q/100)|0)&1?'#2b76a8':'#2f80b3'):'#b6b58f');
    if(pass){const sp=P(mx+Math.sin(t*1.5+q)*30,my+Math.cos(t+q)*20);ctx.fillStyle='rgba(255,255,255,'+(.25+.25*Math.sin(t*2+q))+')';ctx.beginPath();ctx.ellipse(sp[0],sp[1],8*sp[2],3*sp[2],0,0,7);ctx.fill()}}}}
 POOLS.forEach((q,i)=>{if(!inV(q.x,q.y,260))return;
  gEll(q.x,q.y,172,'#b6b58f');gEll(q.x,q.y,152,'#1e6496');gEll(q.x,q.y,112,'#2a79ae');
  for(let k=0;k<2;k++){const f=((t*.4+k*.5+i*.2)%1);ctx.globalAlpha=1-f;gEll(q.x,q.y,30+f*110,null,'#bfe9ff',3);ctx.globalAlpha=1}})}
function drawLanes(){
 for(const pass of [0,1]){const hw=pass?72:84;
  for(const L of LANES){
   for(let i=1;i<L.length;i++){const A=L[i-1],B=L[i],l=dist(A,B),ux=(B.x-A.x)/l,uy=(B.y-A.y)/l,nx=-uy*hw,ny=ux*hw;
    for(let q=0;q<l;q+=100){const e=Math.min(q+101,l),mx=A.x+ux*(q+50),my=A.y+uy*(q+50);if(!inV(mx,my,140))continue;
     const a={x:A.x+ux*q,y:A.y+uy*q},b={x:A.x+ux*e,y:A.y+uy*e};
     poly([P(a.x+nx,a.y+ny),P(b.x+nx,b.y+ny),P(b.x-nx,b.y-ny),P(a.x-nx,a.y-ny)],pass?(((q/100)|0)&1?'#c7ccd2':'#bcc3ca'):'#7b8794')}}
   for(let i=1;i<L.length-1;i++)if(inV(L[i].x,L[i].y,200)){const p=P(L[i].x,L[i].y);ell(p[0],p[1],hw*p[2],pass?'#c0c6cd':'#7b8794')}}}
 for(let tm=0;tm<2;tm++){const b=BASE[tm];if(!inV(b.x,b.y,320))continue;
  gEll(b.x,b.y,270,tm?'rgba(255,60,60,.18)':'rgba(60,140,255,.18)',TEAMC[tm],4);
  gEll(b.x,b.y,190,'#8d99aa');gEll(b.x,b.y,170,'#a3aebd');gEll(b.x,b.y,120,'#8d99aa',TEAMC[tm],3)}}
function crystal(x,y,h,col,t){const[sx,sy,S]=P(x,y,h);const w=11*S,hh=(34+Math.sin(t*2+x)*3)*S;
 const gl=ctx.createRadialGradient(sx,sy-hh*.5,2,sx,sy-hh*.5,46*S);gl.addColorStop(0,col+'aa');gl.addColorStop(1,col+'00');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(sx,sy-hh*.5,46*S,0,7);ctx.fill();
 poly([[sx,sy-hh],[sx+w,sy-hh*.45],[sx,sy],[sx-w,sy-hh*.45]],col,'#fff',1.2*S)}
const WH=90,TH=150;
function drawWalls(t){
 const st=200,top='#3d4565',face='#525a80',faceD='#2e3552';
 for(let x=-TH;x<MAPW+TH;x+=st){if(Math.abs(x+st/2-CX)>VX+st)continue;
  poly([P(x,-TH,WH),P(x+st+1,-TH,WH),P(x+st+1,0,WH),P(x,0,WH)],top);
  poly([P(x,0,WH),P(x+st+1,0,WH),P(x+st+1,0,0),P(x,0,0)],((x/st)&1)?face:'#5b6490')}
 for(let y=-TH;y<MAPH+TH;y+=st){if(y<CYc-VF-st||y>CYc+VN+st)continue;
  poly([P(-TH,y,WH),P(0,y,WH),P(0,y+st+1,WH),P(-TH,y+st+1,WH)],top);
  poly([P(0,y,WH),P(0,y+st+1,WH),P(0,y+st+1,0),P(0,y,0)],faceD);
  poly([P(MAPW,y,WH),P(MAPW+TH,y,WH),P(MAPW+TH,y+st+1,WH),P(MAPW,y+st+1,WH)],top);
  poly([P(MAPW,y,WH),P(MAPW,y+st+1,WH),P(MAPW,y+st+1,0),P(MAPW,y,0)],faceD)}
 for(let x=150;x<MAPW;x+=330)if(Math.abs(x-CX)<VX&&CYc-VF<0)crystal(x,-70,WH,(x/330|0)&1?'#7a8bff':'#5fe0ff',t);
 for(let y=150;y<MAPH;y+=330)if(y>CYc-VF&&y<CYc+VN){crystal(-75,y,WH,(y/330|0)&1?'#b07bff':'#5fe0ff',t);crystal(MAPW+75,y,WH,(y/330|0)&1?'#5fe0ff':'#b07bff',t)}}
function drawBottomWall(t){const st=200;
 for(let x=-TH;x<MAPW+TH;x+=st){if(Math.abs(x+st/2-CX)>VX+st)continue;
  poly([P(x,MAPH,WH),P(x+st+1,MAPH,WH),P(x+st+1,MAPH+TH,WH),P(x,MAPH+TH,WH)],'#3d4565');
  poly([P(x,MAPH+TH,WH),P(x+st+1,MAPH+TH,WH),P(x+st+1,MAPH+TH,0),P(x,MAPH+TH,0)],((x/st)&1)?'#525a80':'#5b6490')}
 if(CYc+VN>MAPH)for(let x=150;x<MAPW;x+=330)if(Math.abs(x-CX)<VX)crystal(x,MAPH+75,WH,(x/330|0)&1?'#7a8bff':'#5fe0ff',t)}
function drawRock(o){const[sx,sy,S]=P(o.x,o.y),w=o.r*S,h=o.r*(.8+o.sh*.5)*S;
 ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(sx+6*S,sy,w*1.1,w*.4,0,0,7);ctx.fill();
 poly([[sx-w,sy],[sx-w*.75,sy-h*.65],[sx-w*.2,sy-h],[sx+w*.55,sy-h*.85],[sx+w,sy-h*.25],[sx+w*.85,sy]],'#7e8590','#4d535c',1.5*S);
 poly([[sx-w*.75,sy-h*.65],[sx-w*.2,sy-h],[sx+w*.55,sy-h*.85],[sx+w*.05,sy-h*.45]],'#aeb4be')}
function drawBush(o,t){const[sx,sy,S]=P(o.x,o.y),r=o.r*S;
 ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(sx,sy,r*1.4,r*.5,0,0,7);ctx.fill();
 const cs=[['#2d8a3a',-.7,-.5,.8],['#44a54c',.7,-.5,.8],['#5cc063',0,-1,.95]];
 for(const c of cs){ctx.fillStyle=c[0];ctx.beginPath();ctx.arc(sx+c[1]*r,sy+c[2]*r,r*c[3],0,7);ctx.fill()}
 if(o.f){ctx.fillStyle=o.f;for(let i=0;i<5;i++){ctx.beginPath();ctx.arc(sx+Math.cos(i*1.9)*r*.9,sy-r*(.5+Math.abs(Math.sin(i*2.3))*.9),2.8*S,0,7);ctx.fill()}}}
function drawMonster(u,t){const[sx,sy,S]=P(u.x,u.y),k=u.kind,sc=k==='lord'?2.1:k==='turtle'?1.6:1;
 const by=sy-Math.abs(Math.sin(t*3+u.id))*3*S;
 ctx.fillStyle='rgba(0,0,0,.38)';ctx.beginPath();ctx.ellipse(sx,sy,26*sc*S,10*sc*S,0,0,7);ctx.fill();
 const col=k==='lord'?'#7b3fb0':k==='turtle'?'#3f8f62':'#c0702c';
 if(k==='lord'){ctx.fillStyle='#4b2578';poly([[sx-20*S*sc,by-24*S*sc],[sx-46*S*sc,by-50*S*sc],[sx-14*S*sc,by-40*S*sc]],'#4b2578');poly([[sx+20*S*sc,by-24*S*sc],[sx+46*S*sc,by-50*S*sc],[sx+14*S*sc,by-40*S*sc]],'#4b2578')}
 const g=ctx.createRadialGradient(sx-6*S*sc,by-30*S*sc,3,sx,by-22*S*sc,26*S*sc);g.addColorStop(0,shade(col,1.4));g.addColorStop(1,shade(col,.6));
 ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(sx,by-20*sc*S,22*sc*S,19*sc*S,0,0,7);ctx.fill();ctx.strokeStyle=shade(col,.4);ctx.lineWidth=2*S;ctx.stroke();
 if(k==='turtle'){ctx.strokeStyle='#2b6b46';ctx.lineWidth=2*S;for(let i=-1;i<=1;i++){ctx.beginPath();ctx.arc(sx+i*13*S,by-24*S*sc,9*S*sc,0,7);ctx.stroke()}}
 if(k==='lord'){poly([[sx-10*S*sc,by-36*S*sc],[sx-6*S*sc,by-56*S*sc],[sx-2*S*sc,by-38*S*sc]],'#e7d7ff');poly([[sx+10*S*sc,by-36*S*sc],[sx+6*S*sc,by-56*S*sc],[sx+2*S*sc,by-38*S*sc]],'#e7d7ff')}
 for(const d of [-1,1]){ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(sx+d*8*S*sc,by-24*S*sc,5*S*sc,0,7);ctx.fill();ctx.fillStyle=k==='lord'?'#ff3b6b':'#222';ctx.beginPath();ctx.arc(sx+d*8*S*sc,by-23*S*sc,2.5*S*sc,0,7);ctx.fill()}
 ctx.fillStyle='#3a1a14';ctx.beginPath();ctx.ellipse(sx,by-12*S*sc,8*S*sc,4*S*sc,0,0,7);ctx.fill();
 bar(sx,by-(46*sc+10)*S,(40+14*sc)*S,u.hp/u.maxhp,'#ffb347',6)}
function drawTree(o){const[sx,sy,S]=P(o.x,o.y),s=o.r/30*S;
 if(o.v==='b'){ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(sx+8*s,sy,28*s,9*s,0,0,7);ctx.fill();ctx.fillStyle='#6b4a3a';ctx.fillRect(sx-4*s,sy-30*s,8*s,30*s);
  for(const c of [['#d2619f',0,-52,26],['#ee95c8',-15,-42,19],['#f6b2d8',15,-44,19],['#ffd3ea',2,-62,13]]){ctx.fillStyle=c[0];ctx.beginPath();ctx.arc(sx+c[1]*s,sy+c[2]*s,c[3]*s,0,7);ctx.fill()}return}
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(sx+8*s,sy,26*s,9*s,0,0,7);ctx.fill();
 ctx.fillStyle='#5a3a20';ctx.fillRect(sx-4*s,sy-28*s,8*s,28*s);
 const cs=['#123f1c','#1b5a2a','#27793c'];
 for(let i=0;i<3;i++){const base=sy-(14+i*22)*s,w=(30-i*6)*s;poly([[sx-w,base],[sx+w,base],[sx,base-40*s]],cs[i])}}

function drawMinion(u,t){const[sx,sy,S]=P(u.x,u.y);const mv=G.time-(u.mv||-9)<.15;
 const bob=mv?Math.abs(Math.sin(t*12+u.id))*3*S:0;const by=sy-bob;const c=MC[u.team];
 ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(sx,sy,13*S,5*S,0,0,7);ctx.fill();
 ctx.fillStyle='#2a2018';ctx.fillRect(sx-6*S,by-8*S,4*S,8*S);ctx.fillRect(sx+2*S,by-8*S,4*S,8*S);
 ctx.fillStyle=c;rr(sx-9*S,by-26*S,18*S,20*S,6*S);ctx.fill();ctx.strokeStyle=shade(c,.6);ctx.lineWidth=1.5*S;ctx.stroke();
 ctx.fillStyle='#f0c8a0';ctx.beginPath();ctx.arc(sx,by-33*S,8*S,0,7);ctx.fill();
 ctx.fillStyle=shade(c,.8);ctx.beginPath();ctx.arc(sx,by-35*S,8.5*S,Math.PI,0);ctx.fill();
 if(u.ranged){poly([[sx-9*S,by-38*S],[sx+9*S,by-38*S],[sx,by-56*S]],shade(c,.75))}
 ctx.strokeStyle=u.ranged?'#c8a2ff':'#d8dde6';ctx.lineWidth=2.5*S;ctx.beginPath();ctx.moveTo(sx+12*S,by-14*S);ctx.lineTo(sx+12*S,by-(u.ranged?40:34)*S);ctx.stroke();
 if(u.hp<u.maxhp)bar(sx,by-(u.ranged?64:46)*S,30*S,u.hp/u.maxhp,'#6f6',4)}

function drawHeroSprite(u,t){const[sx,sy,S]=P(u.x,u.y),d=u.def,mv=G.time-(u.mv||-9)<.15;
 const bob=mv?Math.abs(Math.sin(t*12))*5*S:Math.sin(t*3+u.id)*1.2*S,by=sy-bob,tc=u.player?'#ffe08a':TEAMC[u.team];
 const fxv=Math.cos(u.face),fyv=Math.sin(u.face);let view='side';if(fyv>.6)view='front';else if(fyv<-.6)view='back';
 const im=d.spr[view];
 ctx.fillStyle='rgba(0,0,0,.4)';ctx.beginPath();ctx.ellipse(sx,sy,30*S,11*S,0,0,7);ctx.fill();
 ell(sx,sy,u.r*1.3*S,d.color+'33',tc,3*S);
 const k=G.time-(u.atkT||-9)<.18?1.08:1,ih=138*S*k,iw=ih*im.naturalWidth/im.naturalHeight;
 ctx.save();ctx.translate(sx,by+3*S);ctx.rotate(mv?Math.sin(t*12)*.04:0);if(view==='side'&&fxv<0)ctx.scale(-1,1);
 ctx.shadowColor=tc;ctx.shadowBlur=7*S;ctx.drawImage(im,-iw/2,-ih,iw,ih);ctx.restore();
 const top=by-ih;
 if(u.shield>0){ctx.strokeStyle='#bfe6ff';ctx.fillStyle='rgba(150,210,255,.18)';ctx.lineWidth=2.5*S;ctx.beginPath();ctx.ellipse(sx,by-ih*.5,Math.max(34*S,iw*.6),ih*.6,0,0,7);ctx.fill();ctx.stroke()}
 if(u.stun>0){ctx.font=(20*S)+'px sans-serif';ctx.textAlign='center';ctx.fillText('💫',sx,top-6*S)}
 const bw=64*S;bar(sx,top-16*S,bw,u.hp/u.maxhp,u.team?'#ff5555':'#43d65e',7*Math.min(S,1.3));
 ctx.fillStyle='#000d';ctx.beginPath();ctx.arc(sx-bw/2-9*S,top-12*S,9*S,0,7);ctx.fill();ctx.strokeStyle=tc;ctx.lineWidth=1.5;ctx.stroke();
 ctx.fillStyle='#fff';ctx.font='bold '+(11*S)+'px sans-serif';ctx.textAlign='center';ctx.fillText(u.lv,sx-bw/2-9*S,top-8*S);
 if(u.player){ctx.fillStyle='#ffe08a';ctx.font='bold '+(11*S)+'px sans-serif';ctx.fillText('▼',sx,top-26*S)}}
function drawHero(u,t){
 if(u.def.spr){const a=u.def.spr.front,b=u.def.spr.back,c=u.def.spr.side;if(a.complete&&a.naturalWidth&&b.complete&&b.naturalWidth&&c.complete&&c.naturalWidth){drawHeroSprite(u,t);return}}
 const[sx,sy,S]=P(u.x,u.y);const mv=G.time-(u.mv||-9)<.15;
 const bob=mv?Math.abs(Math.sin(t*14))*5*S:Math.sin(t*3+u.id)*1.5*S,by=sy-bob,tc=u.player?'#ffe08a':TEAMC[u.team];
 const sw=mv?Math.sin(t*14)*5*S:0;
 ctx.fillStyle='rgba(0,0,0,.38)';ctx.beginPath();ctx.ellipse(sx,sy,28*S,11*S,0,0,7);ctx.fill();
 ell(sx,sy,u.r*1.3*S,u.def.color+'33',tc,3*S);
 // kaki
 ctx.fillStyle='#2a2018';rr(sx-11*S,by-20*S+sw*.4,8*S,20*S,3*S);ctx.fill();rr(sx+3*S,by-20*S-sw*.4,8*S,20*S,3*S);ctx.fill();
 // badan
 const g=ctx.createLinearGradient(0,by-60*S,0,by-18*S);g.addColorStop(0,shade(u.def.color,1.15));g.addColorStop(1,shade(u.def.color,.55));
 ctx.fillStyle=g;rr(sx-18*S,by-60*S,36*S,42*S,12*S);ctx.fill();ctx.strokeStyle=shade(u.def.color,.45);ctx.lineWidth=2*S;ctx.stroke();
 ctx.fillStyle=TEAMC[u.team];ctx.fillRect(sx-18*S,by-40*S,36*S,6*S);
 // tangan & senjata
 ctx.fillStyle='#e0b48a';ctx.beginPath();ctx.arc(sx-23*S,by-36*S+sw,6.5*S,0,7);ctx.fill();ctx.beginPath();ctx.arc(sx+23*S,by-36*S-sw,6.5*S,0,7);ctx.fill();
 ctx.strokeStyle='#f2f5fa';ctx.lineWidth=3.5*S;ctx.beginPath();ctx.moveTo(sx+23*S,by-36*S-sw);ctx.lineTo(sx+23*S+Math.cos(u.face)*8*S,by-72*S);ctx.stroke();
 ctx.strokeStyle=u.def.color;ctx.lineWidth=1.5*S;ctx.stroke();
 // kepala = potret
 const hy=by-84*S,hr=27*S;
 ctx.fillStyle='#000a';ctx.beginPath();ctx.arc(sx,hy+2*S,hr+2*S,0,7);ctx.fill();
 ctx.save();ctx.beginPath();ctx.arc(sx,hy,hr,0,7);ctx.clip();
 const im=u.def.img;if(im.complete&&im.naturalWidth)ctx.drawImage(im,sx-hr,hy-hr,hr*2,hr*2);else{ctx.fillStyle=u.def.color;ctx.fill()}
 ctx.restore();ctx.strokeStyle=tc;ctx.lineWidth=3.5*S;ctx.beginPath();ctx.arc(sx,hy,hr,0,7);ctx.stroke();
 if(u.shield>0){ctx.strokeStyle='#bfe6ff';ctx.fillStyle='rgba(150,210,255,.18)';ctx.lineWidth=2.5*S;ctx.beginPath();ctx.ellipse(sx,by-52*S,40*S,62*S,0,0,7);ctx.fill();ctx.stroke()}
 if(u.stun>0){ctx.font=(20*S)+'px sans-serif';ctx.textAlign='center';ctx.fillText('💫',sx,hy-hr-6*S)}
 const bw=64*S;bar(sx,hy-hr-18*S,bw,u.hp/u.maxhp,u.team?'#ff5555':'#43d65e',7*Math.min(S,1.3));
 ctx.fillStyle='#000d';ctx.beginPath();ctx.arc(sx-bw/2-9*S,hy-hr-14*S,9*S,0,7);ctx.fill();ctx.strokeStyle=tc;ctx.lineWidth=1.5;ctx.stroke();
 ctx.fillStyle='#fff';ctx.font='bold '+(11*S)+'px sans-serif';ctx.textAlign='center';ctx.fillText(u.lv,sx-bw/2-9*S,hy-hr-10*S);
 if(u.player){ctx.fillStyle='#ffe08a';ctx.font='bold '+(11*S)+'px sans-serif';ctx.fillText('▼',sx,hy-hr-26*S)}}

function drawStruct(u,t){const[sx,sy,S]=P(u.x,u.y),big=u.type==='nexus',c=MC[u.team];
 const Rb=(big?60:38)*S,Rt=(big?42:26)*S,Ht=(big?86:118)*S;
 ctx.fillStyle='rgba(0,0,0,.4)';ctx.beginPath();ctx.ellipse(sx+10*S,sy,Rb*1.5,Rb*.55,0,0,7);ctx.fill();
 ell(sx,sy,Rb*1.35,'#575763',TEAMC[u.team],3*S);ell(sx,sy,Rb*1.1,'#6c6c78');
 const g=ctx.createLinearGradient(sx-Rb,0,sx+Rb,0);g.addColorStop(0,'#8c8c9c');g.addColorStop(.5,'#62626f');g.addColorStop(1,'#3c3c48');
 ctx.beginPath();ctx.moveTo(sx-Rb,sy);ctx.lineTo(sx-Rt,sy-Ht);ctx.lineTo(sx+Rt,sy-Ht);ctx.lineTo(sx+Rb,sy);ctx.ellipse(sx,sy,Rb,Rb*CYF,0,0,Math.PI);ctx.closePath();ctx.fillStyle=g;ctx.fill();
 ctx.strokeStyle='#2c2c36';ctx.lineWidth=1.5*S;for(let i=1;i<5;i++){const f=i/5,w=Rb+(Rt-Rb)*f,y=sy-Ht*f;ctx.beginPath();ctx.ellipse(sx,y,w,w*CYF,0,0,Math.PI);ctx.stroke()}
 const f1=.55,f2=.72,w1=Rb+(Rt-Rb)*f1,w2=Rb+(Rt-Rb)*f2;ctx.fillStyle=c;ctx.globalAlpha=.85;
 ctx.beginPath();ctx.moveTo(sx-w1,sy-Ht*f1);ctx.lineTo(sx-w2,sy-Ht*f2);ctx.lineTo(sx+w2,sy-Ht*f2);ctx.lineTo(sx+w1,sy-Ht*f1);ctx.closePath();ctx.fill();ctx.globalAlpha=1;
 ell(sx,sy-Ht,Rt,'#8e8e9e','#2c2c36',1.5*S);
 const fl=Math.sin(t*3+u.id)*5*S;
 if(big){const cy=sy-Ht-48*S+fl,w=34*S,h=52*S;
  const gl=ctx.createRadialGradient(sx,cy,4,sx,cy,90*S);gl.addColorStop(0,c+'cc');gl.addColorStop(1,c+'00');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(sx,cy,90*S,0,7);ctx.fill();
  poly([[sx,cy-h],[sx+w,cy],[sx,cy+h*.7],[sx-w,cy]],c,'#fff',2*S);poly([[sx,cy-h],[sx+w,cy],[sx,cy]],'rgba(255,255,255,.35)');}
 else{poly([[sx-Rt*1.25,sy-Ht],[sx+Rt*1.25,sy-Ht],[sx,sy-Ht-46*S]],shade(c,.8),shade(c,.5),1.5*S);
  const cy=sy-Ht-58*S+fl,gl=ctx.createRadialGradient(sx,cy,2,sx,cy,26*S);gl.addColorStop(0,'#fff6a8');gl.addColorStop(1,'rgba(255,220,80,0)');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(sx,cy,26*S,0,7);ctx.fill()}
 if(!targetable(u)){ctx.setLineDash([8*S,6*S]);ell(sx,sy,Rb*1.55,null,'rgba(255,255,255,.7)',3*S);ctx.setLineDash([])}
 bar(sx,sy-Ht-(big?150:96)*S,(big?120:90)*S,u.hp/u.maxhp,u.team?'#ff5555':'#43d65e',8)}

function draw(){
 const p=G.player,t=G.time;
 if(!camInit){CX=p.x;CYc=p.y;camInit=true}CX+=(p.x-CX)*.18;CYc+=(p.y-CYc)*.18;
 ZM=window.__ZM||H/470;VX=W/ZM*.8;VF=H*.58/(CYF*ZM)*1.45;VN=H*.42/(CYF*ZM)*1.1;
 ctx.setTransform(DPR,0,0,DPR,0,0);
 const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#141830');bg.addColorStop(1,'#1d2442');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 drawGround(t);drawRiver(t);drawLanes();drawWalls(t);
 const items=[];
 for(const o of TREES)if(inV(o.x,o.y,90))items.push({y:o.y,o,k:0});
 for(const o of ROCKS)if(inV(o.x,o.y,60))items.push({y:o.y,o,k:2});
 for(const o of BUSHES)if(inV(o.x,o.y,60))items.push({y:o.y,o,k:3});
 for(const u of units)if(!u.dead&&inV(u.x,u.y,150))items.push({y:u.y,o:u,k:1});
 items.push({y:MAPH+TH+1,o:null,k:4});
 items.sort((a,b)=>a.y-b.y);
 for(const it of items){const o=it.o;
  if(it.k===0)drawTree(o);else if(it.k===2)drawRock(o);else if(it.k===3)drawBush(o,t);else if(it.k===4)drawBottomWall(t);
  else if(o.type==='hero')drawHero(o,t);else if(o.type==='minion')drawMinion(o,t);else if(o.type==='monster')drawMonster(o,t);else drawStruct(o,t)}
 for(const q of proj){const gp=P(q.x,q.y,0),a=P(q.x,q.y,42),S=a[2];
  ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(gp[0],gp[1],q.r*S*.9,q.r*S*.35,0,0,7);ctx.fill();
  const gl=ctx.createRadialGradient(a[0],a[1],1,a[0],a[1],q.r*2.2*S);gl.addColorStop(0,'#fff');gl.addColorStop(.35,q.color);gl.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=gl;ctx.beginPath();ctx.arc(a[0],a[1],q.r*2.2*S,0,7);ctx.fill()}
 for(const f of fx){const a=f.life/f.t0;
  if(f.k==='ring'){const r=f.r+(f.max-f.r)*(1-a);ctx.globalAlpha=a;gEll(f.x,f.y,r,f.color+'22',f.color,5);ctx.globalAlpha=1}
  else{const q=P(f.x,f.y,60+(1-a)*50);ctx.globalAlpha=a;ctx.fillStyle=f.color;ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.font='bold '+(20*q[2])+'px sans-serif';ctx.textAlign='center';ctx.strokeText(f.txt,q[0],q[1]);ctx.fillText(f.txt,q[0],q[1]);ctx.globalAlpha=1}}
 const fg=ctx.createLinearGradient(0,0,0,H*.35);fg.addColorStop(0,'rgba(20,24,48,.8)');fg.addColorStop(1,'rgba(20,24,48,0)');ctx.fillStyle=fg;ctx.fillRect(0,0,W,H*.35);
 const vg=ctx.createRadialGradient(W/2,H/2,H*.5,W/2,H/2,H*1.1);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.4)');ctx.fillStyle=vg;ctx.fillRect(0,0,W,H);
 drawMini()}
function drawMini(){
 const S=168/MAPW;mctx.clearRect(0,0,168,112);mctx.fillStyle='rgba(35,70,40,.95)';mctx.fillRect(0,0,168,112);
 mctx.lineJoin='round';mctx.strokeStyle='#2b76a8';mctx.lineWidth=6;mctx.beginPath();RIVER.forEach((q,i)=>i?mctx.lineTo(q.x*S,q.y*S):mctx.moveTo(q.x*S,q.y*S));mctx.stroke();
 mctx.strokeStyle='#b9c0c7';mctx.lineWidth=5;
 for(const L of LANES){mctx.beginPath();L.forEach((q,i)=>i?mctx.lineTo(q.x*S,q.y*S):mctx.moveTo(q.x*S,q.y*S));mctx.stroke()}
 for(const c of CAMPS){mctx.fillStyle=c.mon?(c.kind==='small'?'#ffcf5a':'#d48bff'):'#555';const z=c.kind==='small'?3:5;mctx.fillRect(c.x*S-z/2,c.y*S-z/2,z,z)}
 for(const u of units){if(u.dead||u.type==='monster')continue;mctx.fillStyle=TEAMC[u.team];const z=u.type==='nexus'?7:u.type==='tower'?5:u.type==='hero'?5:2;mctx.fillRect(u.x*S-z/2,u.y*S-z/2,z,z)}
 const p=G.player;mctx.strokeStyle='#fff';mctx.lineWidth=1.5;mctx.strokeRect(p.x*S-5,p.y*S-5,10,10)}

/* ---------- INPUT ---------- */
const joy=$('joy'),jb=$('jbase'),jk=$('jknob');let jid=null,jo=null;
joy.addEventListener('pointerdown',e=>{if(jid!==null)return;jid=e.pointerId;try{joy.setPointerCapture(e.pointerId)}catch(_){}jo={x:e.clientX,y:e.clientY};jb.style.left=jo.x+'px';jb.style.top=jo.y+'px';jb.style.display='block';jk.style.transform='translate(-50%,-50%)'});
joy.addEventListener('pointermove',e=>{if(e.pointerId!==jid)return;let dx=e.clientX-jo.x,dy=e.clientY-jo.y;const l=Math.hypot(dx,dy),R=55;if(l>R){dx*=R/l;dy*=R/l}
 jk.style.transform='translate(calc(-50% + '+dx+'px),calc(-50% + '+dy+'px))';input.mx=l<8?0:dx/R;input.my=l<8?0:dy/R});
const jend=e=>{if(e.pointerId!==jid)return;jid=null;input.mx=input.my=0;jb.style.display='none'};
joy.addEventListener('pointerup',jend);joy.addEventListener('pointercancel',jend);
const ba=$('b_atk');ba.addEventListener('pointerdown',()=>input.atk=true);
['pointerup','pointercancel','pointerleave'].forEach(ev=>ba.addEventListener(ev,()=>input.atk=false));
[0,1,2].forEach(i=>$('b_s'+i).addEventListener('pointerdown',()=>input.sk[i]=true));
addEventListener('keydown',e=>{const k=e.key.toLowerCase();input.keys[k]=true;if(k==='u')input.sk[0]=true;if(k==='i')input.sk[1]=true;if(k==='o')input.sk[2]=true;if(k==='b')$('shop').classList.toggle('hidden')});
addEventListener('keyup',e=>{input.keys[e.key.toLowerCase()]=false});
$('shopbtn').addEventListener('pointerdown',()=>$('shop').classList.toggle('hidden'));
$('shopx').addEventListener('pointerdown',()=>$('shop').classList.add('hidden'));

/* ---------- MENU ---------- */
let sel=HEROES[0];const cards=[];
const DESC={shot:'Proyektil lurus',aoe:'Serangan area',dash:'Terjang maju',shield:'Perisai',heal:'Penyembuhan',haste:'Kecepatan'};
function pick(h){sel=h;cards.forEach((c,i)=>c.classList.toggle('on',HEROES[i]===h));
 $('hname').textContent=h.name;$('hrole').textContent=h.role+' · HP '+h.hp+' · ATK '+h.atk;
 $('hskills').innerHTML=h.sk.map(s=>'<li>'+s.ic+' <b>'+s.n+'</b> <small>– '+DESC[s.t]+'</small></li>').join('')}
HEROES.forEach(h=>{const d=document.createElement('div');d.className='card';d.innerHTML='<img src="img/h_'+h.id+'.png" alt=""><b>'+h.name+'</b><small>'+h.role+'</small>';d.addEventListener('click',()=>pick(h));$('heroes').appendChild(d);cards.push(d)});
pick(HEROES[0]);
$('start').addEventListener('click',()=>{$('menu').classList.add('hidden');$('hud').classList.remove('hidden');startGame(sel)});
$('again').addEventListener('click',()=>location.reload());

let last=0;
function loop(ts){const dt=Math.min(.05,(ts-last)/1000||.016);last=ts;if(G){update(dt);draw()}requestAnimationFrame(loop)}
requestAnimationFrame(loop);
window.__LN={start:startGame,update,HEROES,get G(){return G},get units(){return units}};
})();
